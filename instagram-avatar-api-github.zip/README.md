# Instagram Avatar API

API gratuita para capturar imagem de perfil do Instagram via scraping.